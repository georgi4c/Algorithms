﻿namespace Dijkstra
{
    public class Edge
    {
        public Edge(int parentNode, int childNode, int distance)
        {
            this.Parent = parentNode;
            this.Child = childNode;
            this.Distance = distance;
        }

        public int Distance { get; set; }

        public int Parent { get; set; }

        public int Child { get; set; }
    }
}
